Rails.application.routes.draw do
  
  
  devise_for :users
  root to: 'homes#top'
  get 'home/about', to: 'homes#about'
  

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  resources :books, only: [:new,:create,:index,:show,:destroy,:edit,:update]do
  resources :book_comments, only: [:create,:destroy]
  end
  
  resources :users, only: [:show,:index,:edit,:update]do
  end
end