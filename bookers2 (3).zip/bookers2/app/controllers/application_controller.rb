class ApplicationController < ActionController::Base
  protect_from_forgery
   before_action :authenticate_user!, except: [:top, :about]
   before_action :configure_permitted_parameters, if: :devise_controller?
   
   def after_sign_in_path_for(resource)
    user_path(current_user)
   end
   
  protected

  def configure_permitted_parameters
    devise_parameter_sanitizer.permit(:sign_up, keys: [:email])
  end
end

Refile.secret_key = '473c2ed6bb5d358c77838fdafb48001f861b125ca43db73978bd252e6e0b4da4144486d9204153dc6aa5d63ae4e39440f9fdcbda87d91a29ff89c6d62d94ad84'
